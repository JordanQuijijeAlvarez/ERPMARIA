const poolsec = require('../../configuracion/dbmini');

// Obtener todos los empleados
exports.getClientesEstado = async (req, res) => {
     
    const {estado} = req.params;
    const query = 'SELECT * FROM listarClientesestado($1)';
    const values = [estado]
    try {
        const result = await poolsec.query(query,values);
        res.json(result.rows);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};


exports.getClientes = async (req, res) => {
     
    const query = 'SELECT * FROM cliente;';
    try {
        const result = await poolsec.query(query);
        res.json(result.rows);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

exports.getclienteId = async (req, res) => {
   
    const {id} = req.params;
    const query ='select* from cliente where client_id=$1'
    const values = [id]
    try {
        const result = await poolsec.query(query,values);
        
        if (result.rowCount>0){
            res.json(result.rows[0]);
        }else{
            res.status(400).json({error:"NO EXISTE ESE cliente"});

        }
        
    } catch (error) {
        console.log(error);
        res.status(500).json({error:"ERROR EN EL SERVIDOR"});

        
    }

    };

    exports.getclienteCedulaEstado = async (req, res) => {
   
        const {cedula,estado} = req.params;
        const query ='select * from listarClientesestado($2) where cedula =$1 ;'
        const values = [cedula,estado]
        try {
            const result = await poolsec.query(query,values);
            
            if (result.rowCount>0){
                res.json(result.rows[0]);
            }else{
                res.status(400).json({error:"NO SE ENCONTRARON RESULTADOS"});
    
            }
            
        } catch (error) {
            console.log(error);
            res.status(500).json({error:"ERROR EN EL SERVIDOR"});
    
            
        }
    
        };

exports.Registrarcliente = async (req, res) => {


    const {client_cedula, client_nombres,client_apellidos,client_direccion,client_correo} = req.body;
    const query ='select registrarcliente( $1,$2,$3,$4,$5);';
    const values = [client_cedula, client_nombres,client_apellidos,client_direccion,client_correo];

    console.log(values);
    try {
        const actor = await poolsec.connect();
        const result = await poolsec.query(query,values);
        actor.release();
        res.status(200).json({message:'cliente registrado'});
    
    } catch (error) {
        console.log(error);
        res.status(400).json({error:"No se pudo registar al cliente"});

        
    }
};

exports.Actualizarcliente = async (req, res) => {

    const {client_id,client_cedula, client_nombres,client_apellidos,client_direccion,client_correo} = req.body;
    const query ='select actualizarcliente( $1,$2,$3,$4,$5,$6);';
    const values = [client_id,client_cedula, client_nombres,client_apellidos,client_direccion,client_correo];
    console.log(values);
    try {
        const actor = await poolsec.connect();
        const result = await poolsec.query(query,values);
        actor.release();
        res.status(200).json({message:'cliente actualizado '});
    
    } catch (error) {
        console.log(error);
        res.status(400).json({error:error.message});
    
        
    }
    };

exports.eliminarcliente = async (req, res) => {
    const {id} = req.params;
    const query ='SELECT eliminarcliente($1);'; 
    const values = [id];

    console.log("Eliminando cliente ID:", values);
    try {
        const actor = await poolsec.connect();
        await actor.query(query, values); 
        actor.release();
        
        res.status(200).json({message:"El registro se eliminó correctamente"});

    } catch (error) {
        console.log(error);
        res.status(500).json({error:"ERROR EN EL SERVIDOR", detalle: error.message});
    }
};

