import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
    selector: 'app-panelcontenido',
    imports: [RouterModule],
    templateUrl: './panelcontenido.component.html',
    styleUrl: './panelcontenido.component.css'
})
export class PanelcontenidoComponent {

}
