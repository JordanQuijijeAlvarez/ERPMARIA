import { Component } from '@angular/core';
import { RouterModule } from '@angular/router';

@Component({
    selector: 'app-404',
    imports: [RouterModule],
    templateUrl: './pagina404.component.html',
    styleUrl: './pagina404.component.css'
})
export class pagina404Component {

}
