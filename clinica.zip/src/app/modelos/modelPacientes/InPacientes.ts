export interface InPaciente {

    codigo: string,	
	cedula: string,
	nombre: string,
	apellido:string,
	fecha_nacimiento:string,
    edad?:number;
	direccion:string,
	telefono:string	,
	email:string,
	descripcion: string	
    //estado: string,
    //usuario:string,
    //fecha_registro:string;


}
