export interface InEspecialidadMedico {
    codigo: string,
    especialidad: string,
}
