export interface InSubcategoria {

    subcat_id: number,
	subcat_nombre: string,
	subcat_descripcion: string,
	subcat_categoria:number	
    //estado: string,
    //usuario:string,
    //fecha_registro:string;


}
