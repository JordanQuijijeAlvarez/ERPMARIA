export interface InLogin {
    nombre_usuario: string  ;
    contrasenia: string;
}
