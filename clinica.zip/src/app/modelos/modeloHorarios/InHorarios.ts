export interface InHorarios {

    codigo: string,	
	hora_inicio: string,
	hora_fin: string,
    estado: string,
    usuario:string,
    //fecha_registro:string;


}
