export interface InResposeToken {
    token : string;
}
