export interface InMedicoEspecialidad {

    codigo: string,	
	codigo_medico?: string,
	codigo_especialidad?: string,
    // estado: string
    //usuario:string,
    //fecha_registro:string;


}
