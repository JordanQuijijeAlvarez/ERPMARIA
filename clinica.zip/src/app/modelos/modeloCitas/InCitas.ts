export interface InCitas {

    codigo: number,	
	codigo_paciente: number,
	codigo_medico: number,

	codigo_especialidad: number,
	motivo: string,
	hora: string,
    fecha: string,        
	estado:boolean,
	usuario :number,
	antecedentes:string;


}