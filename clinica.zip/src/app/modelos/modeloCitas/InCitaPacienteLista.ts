export interface InCitaPacienteLista {
	codigo_cita:number,	
	cedula: string,
    nombre_completo: string,	
	edad:number,
	corrreo: string,
	telefono: string,
	fecha_cita: string,
	hora_cita: string,
    estado_cita_texto: string
}