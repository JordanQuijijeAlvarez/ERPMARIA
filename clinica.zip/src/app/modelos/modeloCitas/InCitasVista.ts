export interface InCitasVista {

    codigo_cita: number,	
	codigo_medico: number,
	motivo: string,
	hora_inicio: Date,
    hora_fin: Date,  
    fecha: string,       
	estado:boolean


}