export interface InRoles {
    codigo: string,	
	nombre: string,
    descripcion?: string;
    estado?: string;
    // fecha_registro:string,
}
