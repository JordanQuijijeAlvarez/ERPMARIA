export interface InProducto {
    prod_id: number,	
	prod_nombre: string,
	prod_descripcion: string,
	prod_preciov: number,
	prod_stock: number,
	prod_stock_min:number,
	prod_subcategoria:number,
	prod_proveedor:number,
    //estado: string,
    //usuario:string,
    //fecha_registro:string;
}