export interface InSubcategoria {
    codigo: string,
    nombre: string,
}
