export interface InConsultorios {

    codigo: string,	
	nombre: string,
	descripcion: string
	
    //estado: string,
    //usuario:string,
    //fecha_registro:string;


}
