export interface InConsultas {

    codigo: number,	
	codigo_cita: number,
	peso: number,
	temperatura: number,
	presion: number,
    diagnostico: string,        
	tratamiento:string,
	estatura:number,
	usuario :number,
	estado:boolean;
	observaciones:string


}