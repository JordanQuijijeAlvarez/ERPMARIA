export interface InCategoria {
    subcat_id: number,
	subcat_nombre: string,
	subcat_descripcion: string,
	subcat_categoria:number	
    
}
